$('.table > tbody > tr').click(function() {
    $("#empInfo").modal();
});